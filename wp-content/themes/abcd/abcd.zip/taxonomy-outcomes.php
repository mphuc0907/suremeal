<?php
/**
 * Template Name: Outcomes Taxonomy
 */
?>
<?php
get_header();
?>

<?php
get_footer();
?>
